<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7fe7c50b58f01fde61f477fdc2f8c813',
      'native_key' => 'core',
      'filename' => 'modNamespace/9f1dc203bdd15ccd68bb3a0383976c92.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '8e1684896b80c91ddf3493e26a6430f1',
      'native_key' => 1,
      'filename' => 'modWorkspace/081f22f1027ac4b2b0433c17c72b771f.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'd72d02ca354acd4d9a67eb01d06732e3',
      'native_key' => 1,
      'filename' => 'modTransportProvider/e7cbde4d1165ace0c5bb00aa47dbd2ec.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '178ae9cd59700e1a6299f35e1f1bcb4a',
      'native_key' => 'topnav',
      'filename' => 'modMenu/8ef1e85347300206c02edc37c8413156.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ca7b49444ae5fe9e9087a97be628d8c0',
      'native_key' => 'usernav',
      'filename' => 'modMenu/cf8e1d8a0734e9b8e68e435c6f28a10e.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '44ab0ab3324acd3cce4d97c1f60b7602',
      'native_key' => 1,
      'filename' => 'modContentType/e0ee7c329faf74a32972bfcaf0e54498.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '4e358f43c8fa65d83a9e1bd43a548a5a',
      'native_key' => 2,
      'filename' => 'modContentType/a66d5b6c4937ffd3086fb1cfed2eaf4d.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '954ee592dd1b0d7a4a0189879858952e',
      'native_key' => 3,
      'filename' => 'modContentType/418647044bf7e602cf2585ff31bdd890.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '043ec71db6cce69bb46db1d8bb9e9e7c',
      'native_key' => 4,
      'filename' => 'modContentType/d6db73259cef227269f515d63482ce7b.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '296548061d86e70f761619a675d2bb0e',
      'native_key' => 5,
      'filename' => 'modContentType/399e43169befb55a157bd31455b3911c.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '0cee6135d14a007d845395b54652980a',
      'native_key' => 6,
      'filename' => 'modContentType/e825ec4e23832be8f38c90e2258e31ac.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b016b3c0a2b73e458a44f8505a7aab2f',
      'native_key' => 7,
      'filename' => 'modContentType/2d476d365201d9b3728cd56e1a1c81c8.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e19a570890e50662a4b2b7c5f02ef0fa',
      'native_key' => 8,
      'filename' => 'modContentType/481fd61878189a843faabfb4d65b8b12.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9f8823f2668af1adc44d3ccb531ffd1e',
      'native_key' => NULL,
      'filename' => 'modClassMap/e5797ec105d79d5fda84a5119dc99469.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'af3d98501fcc9129569875c3ff169f91',
      'native_key' => NULL,
      'filename' => 'modClassMap/ec37de5e82fcdc03d99c0a88a1d2ee0a.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c905819135bdcce79cc777751f618b93',
      'native_key' => NULL,
      'filename' => 'modClassMap/a5ec68210be3a3ba56ceef6e502a4863.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '81cfa0d3b91eab1159e553dc67b70b97',
      'native_key' => NULL,
      'filename' => 'modClassMap/7ce86ddd0d5e438eb09110415a502d1a.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a7986863789261c5e92aea3e48c10eb8',
      'native_key' => NULL,
      'filename' => 'modClassMap/24be1fd07209870b32f510af41eb6ce0.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '77433f12b18b707657c22dc359ff0f94',
      'native_key' => NULL,
      'filename' => 'modClassMap/f2580a435c92c7797986c30966d3054b.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '02b923a295fc92862f52ffc9c2b63148',
      'native_key' => NULL,
      'filename' => 'modClassMap/30d904519f4988910b18d12c1419a8c5.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ba1807a3bd40eaef2bca0ad27b39d4d9',
      'native_key' => NULL,
      'filename' => 'modClassMap/b5179998a6338dbf4527f47121d707a9.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '25f6f5329ce3043777fb5c6be7aae5ec',
      'native_key' => NULL,
      'filename' => 'modClassMap/af28efce7548e4b0c3ad1eca0e79b0dd.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36bdd5675ccf02fd75064a5e8bee3286',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/e45f02bc41c04317185af0ec481b9e43.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a186096b6a1115bc99a1f43bc176c23',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/3772946273dc9b87839276790c90979b.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1257c21110f70bfd3c92b0067f609cb5',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/a4dec2a3bf383aaf362836dd02ea6060.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90c20bb2978135dfddb3d97b3150d733',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/e80c69172797c028863ba2d5f252065d.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4697106fdc2aede5a1c7493cbec18146',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/c32914fd8c62f489b513850d2ae789d7.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a11cb572622d8b3ae564e24ff509fe3',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/57b86ed75f236099b06f8b98f387986b.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '24b6be901e4c0f8cd3a8a20d5fc625ed',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/9f453f7d8bfd210f32c8394bb41e4290.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a721a8c7bc8a3f39d9d1b52ba057565e',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/7deac6025db47895d19c3c525a7c74a2.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef714fa16ae99e87dbb1c4173de56ca1',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/cd11f8a653e0fcbea67f215f9454e27f.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e4096efc4f21d7d3798de77ede57ada',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/396484e3a31659a90911f3c22a10aab5.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9060e499328ab79bec8514a971ca41bf',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/14cc26e40ece909760bcc210d94ad3af.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa9759ef0b565592cc537209544a33c2',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/cd5351770706662db1f74265cc33af68.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b1ab6f4b7a7518b650f31677206e910',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/74c73900473e38692a8cfba8fdc7f6ce.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5640cfb1e3ec3a56a12055286f5b0347',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/07a1ab920c7b1a363e684dfaba671dcb.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9057a0d6129c3123672b3eab505f35e3',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/4ad657c8b506d150ea8cce3d3cddcbf2.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fbdc2297750ca33bafb43dde54f558a5',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/1ab711b46eec71cc67aa28783cc16cc9.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c6923bb9c576b50adbcca208c82cd42',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/71bf9db460c9b7320ffcd45057af5513.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'afea7b3cfa9718aadc5bf810d9d6d8ff',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/d8d2fe75c5822f573fc9474901f73eed.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be6a6d35f8961c376e48c8ffff3cb6e3',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/2887c6f25913f1ca2045480b268b59a7.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99aa279dfe123687fc2f8865bb1ac45b',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/bd31fe49fd364e0c06fb664d07677b7c.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7f6b7d8d7b44cfebffb5f177f2fffe1',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/81a2d2022e2d69261ef3d18c4729f286.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59526366966013b5f18752845489ab7a',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/49fdbca8cb3954db00aa208e702e2a0e.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14693a2b4eeb7fbcaf928aca0864d062',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/6e217f4491978d5ed5723358f84a6bae.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a449019f0c5b0342d109fffdf07cfcd6',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/a2fa08039b0d9f22448ad11b46fd600e.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0c4f085359e5ebf4ae3e0cdb60678fd',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/0d251c20169fcceb4cdd66951837e273.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8e74efa442a3efe179019b4fc05034a',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/88e7417c443b8005ad7ca5fcf576877b.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '023b84b96d7ffd5d622575d1b32f8169',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/e8c7843d008efb84846602d5e4367428.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af137c87387411d755d51e10ee5e757f',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/d9e1df1bb97ad1564db712dffdfb9b60.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82369a5d22379e44b66935fff92eb892',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/2ba3c18c9337d43fe0a39c1e88a1bc4f.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebd14f3acd6a6f9ded0ab33e6630a759',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/865469fdf879ac5ea3df3d5ec1679f30.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27bb95a52c0f775263e102d0c2339b80',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/adf2aea50bf8e9f2cf03283c7b7042b0.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89cde50b56453c330227636fe8321bca',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/dc85078bc85054dffc5451d881a9fd92.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '926d690d5489bec87d0bcd350254b5c5',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/932ed1c8fe2a77611a5176f3468507fc.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f639c1e0062f5f414d0daa409bfb86a',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/928624d6a32edd29864b1159f9f985ca.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f95d4e98304965bbea0467f0bd88f40',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/ba21ef22eebbb702a4c703bb1621f276.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '041d6a3cf5c3aeedefc4e2eb0a75a14a',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/7c8bead7b30cb7609f07b58f8aca907d.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f52be99da6715a90bc58284653887ab',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/2d251fcb17d99b7cb993d5254e4bd6bd.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eadeafc9eeec86ea86e74d2cf475dbca',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/127e961adfc72aceceaf89090faf48aa.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce5fa40e9cac38f775514631376ff6d1',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/5a241fe9b1791e3d2a7ddd2e2d90076c.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69ae558972bd573cd57ccd7bca579118',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/007e222bdf9ef992ae9d95a1a8b90108.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '982e2e1452ae37576a02d2504ffc8e0f',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/242d3585b3b8612f95b4bdc00dcc4063.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '775fb7cda5c884055c0037ac34173b05',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/3ad68fd9e6dad5da5cb769313fa0fb66.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'caa562564eeb3e7325be31060eb45fd1',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/1b40f133d4e014c537c5b10d8cbf0c41.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50ce4ae431346387da5a3d339b5e53b4',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/ea2111ffcc5fdff813633c01e94c463f.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cdde19ef0b4824886c48f8d034dfa8ef',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/49e45ef1a3509fa46cbf9d499e1d233c.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec11c291063dd0de2e2e58ae874d0143',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/17d0a962e649dae141bcfdb603b65067.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7b7c87b49a482b02dee7d88aef41158',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/99d812d9fbac5bd05ea898464d79a85e.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '543861b60d0f736f16673f1571e011f8',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/60336de1cc15e797920878d928eece0b.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2149a6793837e26f26e73be95b72a78',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/c9bb91bee668448f318df4c400aa6af3.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ac3e2eea70b72d2475d9e4a15a4f30b',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/c4bd111d3dc9db874016568ce05e3017.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94a5f12a092a30188e8376e2430158b8',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/5f9ca7f418cf4905e2f7c206ecc9ba0f.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f05dbabb2faee0a46747eb635b4aaa61',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/ba0d9a4c294cbb021cece48a8a831f96.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38feef7519bf01af263b3a15f0be0c7e',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/544362b94c4b24ed59e66e4f206c5d25.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc8d8bf64b3fa4644dcc113ac42f7318',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/58981337f1e5b58edf7b1e35a7b4cad8.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0a6809fba66a0a0153c2ce2399881ec',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/f4e7af339803e224a203c01a5c838222.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11b3917ba5f4efab5c4d53dfd09577a9',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/35e10dbb370535b3dfe8931161b05531.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1f8b76b129239c34a536cd2cdb2d126',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/e211edd32a99572c6a05c4a793a59b8b.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3f48b6caf931e469fe3af95b2ea8df5',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/f3ce058c59a9cc91fe221cd6854d6f8d.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1822c25608b8cd5d524c09e84eac4270',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/1841d4a9735e473f6a07ae4e45d87d6e.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa837c7f62fa40700ef1ed92e51bd32a',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/e70e1c313f44712afe71e55a6b846c19.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2ce3fd9367baa34b3fd3523f04e8b8a',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/8fa941358188913f7124913055bd8b8d.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84291628cea62bc0352e8d39b836b2fa',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/425e8fd2a9bd55270e7e81aa6bc345ba.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a188c3a512d604644967d5a2450e8b3',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/0f6ef5c39b5397329496a18b7584f6de.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec0165cbd7b6d6247528832ece249a56',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/e171424724a79bb90ce1d2c96ea7dd5b.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42319ad3976c4c75575144864b72aefc',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/09bd39c5ea502284fa1187ca4a84febf.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26ea5d5c5269be19dd0df99260f9b042',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/8a68fb741a5a0ad76b930a52fceb5ae5.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cea55f361fb07d7e8c4115fefad94121',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/2676a904121cf061dbdb0c266632d158.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59f3dde0b007258fb2a3e3f6b921ff3d',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/fb88cfdd5c89db03eeda82d610dd7f3c.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc2e2a049c6c52442a56ddb357b2a132',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/3e56b1ffd0d4f8c2514d5761601b448e.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd0096e08d2e372c02220fc68aca43b4',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/0c84e2709c17b26ae17f42a2fb51e582.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '919a0d06da988659045b22f1a3529f3f',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/ab6c757bc7ed46a08a52b913a98c82d1.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec3d8860cadfc2a9b3bd12926b1f8b7e',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/ead1eabf24f12a442cd1b69fa7b2e561.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dde4cc9fb2fd6fa3bcf06211c415634b',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/4df098d470c10166269f2ab625b9dbb0.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69fa6873e7afd62dbbf988344151d028',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/6249548a04ca6898a7cd87434b86ba04.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15f78da4bab2a50fe4ac0c5b974dac95',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/c925198ba08b2488e73919d516fa3045.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd863b4cee83bf7342f92f7bb4929f165',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/1af71e16de50b12649e66b8220239571.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b549ced2f13ea297d7944a2456dff23',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/0418fe424a073620a73c685fbc8f66a1.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd734b6c780322572ddc612ced89025d7',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/6abb2e1b86703974a573321eda8247db.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8e002d650b43ca811ead0456160d4c7',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/85bb6f1a2e3c2baeaa39973084b09d6c.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '453ee57a31e41ffe519863754e4fdcd4',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/026d654f874ba52c58bbf30d56e6e3cf.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '423a9bbd27a6a3e0545a60e08998afb2',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/92e88dc58301d630529204c223be557a.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce2129ce368a21c89bc3b7d55976c2ca',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/774ca402ac40e08c1bd5dffe099a45d4.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c42d8125096c09e1a73eef70b63cfa19',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/4c75b7d61aa6e3d042035cb1e906efd1.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de778950498416a03454b7414a3ce5b2',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/bd846b8b4afcfb399b2008c32db0dbe6.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a541b549c55ee30c53d89b194448f58',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/c22a755d6d2b00595f2e7118450bf545.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebf1363147fd11bff23fd0b20f3f913c',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/3ed573e6ccbdc345cc0e865441052d0d.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '00adf0875fe4fe7251335d68be0fcbf7',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/e2c469ab9baa9769b77c80593c8ab732.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '987b977efc8e0d5528608578eb6a2de1',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/a28e9cad8d85d8748eb5b573b364bb25.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6ea52171765f01e6bbe6047e2d58d57',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/49910df183ed781f2b3c2e2903f35937.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48a9fd7881833929df0f410f04ede5d3',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/54c3cda3ce4e8e0c1067e430a4016bc3.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '543504ed8c5fc275c009f3c2f254c2fc',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/2e4add3aece6810952529a3303f13abc.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9966e10cafa6ae125ffea59d080f0df0',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/7322016ced682efdb48128849ef07285.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75cd06bc6c8f3a8d7f6044410f520599',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/905faf106c25b04d84972b2fbd6cd7d6.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9c4d72cdff927b6c9d915a940bb7972',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/1393697b2944a540fa75249ab62f69be.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f66b69612630f977064b68bedde79435',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/515d554c859615ad8f5170a2d714c7c2.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a80ab98c523848c827e484d02afcfa4',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/ba262ee97807af0dfab7a292edd163eb.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7178331eb8cbad5633a2208388a4542c',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/12a8cb21d414c0a20d0e721972fe7f40.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61930d85c80f28c50bebb0e782c0ad7b',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/ea7a5d92f0ec919fd59e78379db76a6a.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5581e41213df26c59ee5896d51569e5f',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/36f53c99b7be2639519bc1cb83c659c0.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2396e991a6ec57a7ef3a9dfd6568f3e2',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/f112182f766c6f021edd698e4192456d.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8736d7dc7680f4900c545aed3b5d427e',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/7dfec8b2024cf2ce7933cb07000dc48d.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '157fc961a500c668c2e35d6d6df632eb',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/4ffa9d1660c37acb5ef3a227d66ecb3c.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '334d1ea9029b32d7f85cc6637867153d',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/0d09f9078a3982720cc083899394fbc4.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a3e6e705c6a747661463368fc029c81',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/5b331ba3199121132911271f8dfe5625.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da9f02dc4ff0f81cef4fe0cdfa6a46e7',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/6538081db6869e2bbdc8439b9b4e4dcf.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f782c639e1e8ec159642bc3dd1f6c20e',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/e35c8258ec8988388db171705012ce19.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '795a2d173e0c6f60dadf86a0ba24e839',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/f4bcf539c378097f52693d3b0e8b8612.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b811f5d812d978e97ce9de058ce6821c',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/03bf5f1ca596dcb4d388c2497ad09fb8.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10fa3975f478b0ca354ab0f66cf4b7f3',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/667cb099048748c3f21983f9dc6a84f4.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '580b9b7ba1efb7a46ab3df0ce9cdbd05',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/90e994727cfb00c968082dcf18557963.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8caf1b82fdf8c8c254cfac50b5856981',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/baf6a3c3cbb8bebdf9300445c3829951.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfa6274c2fd50ccc857ce71106adb823',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/3b3cba8f5b8fbf1cdc842a0ee6518a29.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '237a49b8cf285703bbaba7346c8d71be',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/d11237d9fc38932a8512020c6574971a.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '779db58480ef647ea89f713984359791',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/fb164323af03da7864d6d5226078a497.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6484756c649f39604fa0b47231149a1e',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/3cd27bec8d0f14247d433d62140ddcae.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '616ee0a35b296ed858833fc8fe9846bf',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/46407b99ed2a214378dd22115a4369fb.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ece93d36220f308efe0138ff5781330d',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/39df722088c4a85d37b4f68235459d40.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9151db8a9004eb58c0e4b3283d83c07a',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/6eae564c5c10a4f036998d4b22253f45.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '624b312710331792525013a469a8c4dd',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/de5019681138274fed03e0f2840bacc6.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a43679215174386193578d33fa456b78',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/bc70f28a92ce90d6c189f8133be780f2.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97204f1d532391586a2649f3042021a1',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/2130cadf32dfe50181ec7f5e9b936002.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ac9422b8ff92eca0a3e55560d08d42a',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/e2ce4d0d247af16d3edf618e5272ea0c.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07540337c9949c00f91690d232ff4d74',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/d6f915e90ace77948b8650c76fa9d6ce.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95164e97daf224fdb255763975a68665',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/e9fff2667ea23f19af5b956ac55ebf04.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b93a2704c6bed67571db41a2f06c6ce',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/1b0719e67a41b4eb1ba70b7ee23f19a1.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f58f0dd6b98037804be4ce2cd24dd1f8',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/a4b9724a2bb524be9c263d965e85128a.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c5fbcc95b43d1fc73f2e5816b45d3b9',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/5bbce165fc1c0872fe9728c6154d8be5.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ffd5b092632614f24084c2bd83dde21f',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/ba45f1a88eec8f03f158dcea09a6ea06.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60aeef5b2fc9869f16afb3e14328392e',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/0e4f658546fa612064fde873c4e23b9c.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '735a650fabf684ad47545dcd13026226',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/8db5378874df79f2ef2517035579ca7b.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3fe6bf7ddc42b2eaa2d3b8b2f7d104f7',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/bc6116c18aa08e80e3f023f09ccae37a.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e18699b2e798f4ebfeefb22e92af57cc',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/323914f198adb84093f39a7c5d1f1143.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13d439579533d6db228321a44723fccd',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/89d80115642abb1c8f00eeed30d341c4.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '831f1366e6cee469a5a97b5d37d7bccc',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/507079b96a69c4cdbb928fbdb33eb85b.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '221c5d68b60a480cc3958afda2b1b7b3',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/fbb5cf1aa5e2fe9f9a30482d6c7e899f.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c295b13d72f077c97382d573cd81d23',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/441b98db87b4436ff98789c094b9f581.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad8af446e56fa8b9954d61da59300abf',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/33cb875594384a5a36f921056b9b9d9f.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '505c6e9ae8d27ecf8f6494678d8b9d29',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/9914de26a3860581f4e15156d13e9c0f.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f23273ecd8d2c6ffaa54ab237303f15',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/337e1793f54d8ebe39d677a1165a34d8.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f2d74d2107e69aa968ac44e28441cfb',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/bbd822aae88619e442a7e8fd4d63ebf5.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c977d3cb2da498e3ecf52cc2d508f12',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/27eefa1ee419d96ba757bdc5db3e3220.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '946331d041ac5572830fa497cdb71b52',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/2db50efe9aa91edba782f6dc1eda2a03.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cdaa6fbffb2a545456fb3e61562117a7',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/166cf6b3c8b047a683c25f1a79f5beb8.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '250f7f24fe9b0f7b2cbb34ddffb32b55',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/0853a28e373936aec0f5ccd19ed5ec90.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '574345bde69c0777bfd8e1b5d697fa58',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/b976dd47f179088c39334d10e0c3a2de.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b755fd43f293f788ea338f6e8dfc3ac2',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/744efaae90bf9350f43029a7809c4cc5.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f3e9b2ddd51900c212aee870ffad414',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/42ffeaf03c8e564d41ee9fe032c443d3.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8337945b477780204713cfa2331147dc',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/c81ab5356c6f9b1965d5c66da50bf908.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5c48b789bab648fe0d1bce8486e3571',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/0e42913d2b08d60d111039a9c9803108.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba49dc5c8650b5026919dc9df93eb3d5',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/5ec4b5fcd342c0abcffb7da0cec564c6.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0c347f884b35fef72aa5bd4b799b145',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/0445346026f2f7ed9f9a18dffe608ad3.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '748aa56cbe3138138ebdec0096c81df5',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/6dcc9df0603c4649b908e8fc5a5d966f.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a393145d12913da845d04bff776ce26a',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/7a1ca6486ae95934d1b34e8e3c6d4578.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05ecff4b8d8c9a7ee6066b49cdca9e01',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/5536d1b2f91b18c5dcd2e0a6431686ce.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3313a147ff52fad65fcf07363d43390a',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/25cdcdc3644b439e6a3403552884d9d3.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d100b255cc83406a9707c4e632fa849',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/7ee22c95a6d846248f32718bb57992a3.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c45f87b6226b1a704da3f3fa50d698ec',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/8024f2a3bbabcddb57eaf2944ad0571a.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c66a0f1b18613207bab28a1cdfea150e',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/6d446e0400f789fc3a4261a7e4a650de.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c712a012f5a047556d8783338637c092',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/7674e6251ca397eb9889126545eb004b.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aca6525eba8f2956b66ad69d8772d203',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/f23a11c8b9f1a33e57226c692387ab6d.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '672689fa346918881ea3567da26eef04',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/b9e381a938e6cca80fe9df04581074d1.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45b8297cffea226314772d5760471f94',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/954c142826695e895b5bc2777f646f69.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a21d58b1f93503438eb9c2b06bfee0a8',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/3d0b7e8ab3946299c4c97d65a3880985.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ecfc87defa914367bf048af13d383c67',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/350ac613fe711ecfb208aa412e943178.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db001ab1701abfcad1523cbe739195af',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/aa21a6815fb5b44e8e681d07745031a2.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42c9007a3f6c6a75180746b45b093c49',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/5551ae90fcd4f2860e199e29c13e6766.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '288646b94ed9a7cbb3fbcc86b2c879ae',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/4779762234ac043f03c26351a2b98d25.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b9cc8df12e2cebf5f58fe4c8d339e38',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/84ff3c358ed1d6a1c03e6c1c5c2ace00.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f054d1012be09b4d3d0ee2211a309989',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/aab087534cae122cada61d216c8a7675.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef9f0fdc5af6f9602ce713a2320626c9',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/0187a997dde1bfafddefd21887702bd0.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c66ecbda68441e1c67e363369a91c467',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/9b6c2714bfa971c8018b251780ba7ce8.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0f72cf69905e5e3871a1b1960095cde',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/75ca771309a0db9ee76130e6f505e1c0.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a6829ec763c42ca4784b0dfbcaf22a1',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/55a05502960dd9aac529b3bf6931fbcf.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9b6324bc6e0ff8b9296561886d537e2',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/4f984ac4f7271772b98f64328037be41.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77d0b8755d588e0a30a494042c5bc2ef',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/7920809d65adb68050807df2a2f2ecd9.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edf2fcd0061eb6f695b43988940d6379',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/8336dfc96ecd6fa578d5c6b9ddbe2c19.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8169494b82a11978cb2f467919b93d3b',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/389e7fc05fba269b3c1ee73f1daad279.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '068bda229701081f67e62e20dedd5ff6',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/ee69e769413a71ff91f715acbe901f02.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9cc67c350b7cdeb1b505c675ecae93a',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/31034aaf3679c101d500cc1b8897f728.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '488302cd5a4cf19ee4c2706540465488',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/f280e453184012969114c3e342ec9258.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b4aa8af6d44185093b1f119637ec608',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/165b0d9bb817171862a14d5009f76f50.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b84030c07f367547995d42db3a27d827',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/893d129f2e9c76491a8ff5459be808dd.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10d7cccde667ffc9b7664cf3b5690cb8',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/6b26ad553b96547bb54e612cc4bc46ac.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b649eb568dc17347fe665993242af6e',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/a7a043725614eb7c2258d654a108c410.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b57a7cc87189a4465d740bd3b5b78ac',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/54dccd9dfdc5c3d6194d1ec465bd42f9.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99b55155dc467182857207baa178a3e0',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/ef7123b6c8d242fd5ef3a37a3c68f205.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94a6fc3a70262c283b73dd5e7c0c6974',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/6029aa649f03f369a259f0300c8f456d.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3de607906edb3032851678711ca97ade',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/1b4f7503500034e9bf6a708bf77f8141.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d837b7e7ef3fc3419048ef20ac12c6f',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/024d7037275f5b70c3f813e3f0677316.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66171a92fbf303d45516046f76ba9744',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/2229f762792530a468634e2c29fc4360.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '948935adfa316a4575ead8610b906244',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/0d90343e697231c74f7e653a8e2a5864.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e0f41732ffe9fd9c95e439dd5cd3d1b',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/7d212c41e2ce1ef896ccc4a823d4f013.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f74126c4d487f4de9797043fa49203e4',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/4f30602a5af8cd240097122094a9681a.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9421c56abcdbc8f40bfc1c7de57920d8',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/8a3e5a0491aecfdfffc9d957da865e10.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebfbf6db5089421579760a7b4b28d1fd',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/49ec0a6ab6015c010fb1bf1858964931.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b63c5315f4f86274d5e97ea611951f6',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/7f1ab85b367456f4afd507756f49c7ff.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53e53ebed27687aeebe786b30216ba89',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/2cb8b54ba67e706b7dc87e6f473edfe7.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ffa88e071979d659cdfc43c83289e41',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/4d3e1690b0a52a24beacef8d29b0e496.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '367e59ba801ca0ddab85aa406d53d6ec',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/e9c426b8fc5e452bacf6634bc55e72e1.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfd5e2b891fb5ed107dafd97a7071674',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/4b812e0fb581c4b487492fd0126ff7ca.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9451e09476e8fecd76a6d2384a9e8844',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/d435b2ee4d75d9b7ebf1334a64d674dc.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47fc44e270dcf679e35d7ebba16502b4',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/cddbe6392628c767c346c70092623d9f.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b28b2a6cbcc3316f7e03117dc07177b',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/5562f91da87521f3ab2049bcc2ffd2c6.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e190a583f6043cdde474a062b0c78e33',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/7a870eef80f3cfb7d56d09b4ac7bed0a.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48c829349b76c64fde37354c35d8c83e',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/89b869f94a36cef0dbbeb129cc88583c.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72311e3e561385d6a0e83f784ff326de',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/126643d09aa925a607efc2cfd93cd507.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69a149b26144421c80b7358355b20d4e',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/d70c19e998bc744aacd684bb860c996c.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fb4b81ef6763c52db4200d3bbe0fbbc',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/8e51aa2ed091fe238dcadbfa7ac4295c.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4352489a75c31267fcf928f2dbbe37b',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/d1ed0ae177ba021c379396f79bee30be.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e177ce248a7a6bde8474127da85d266',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/d83e4c2a804f7df958fa3eb76d64ba5d.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '077f5e2f4905197a132ea61c397d5786',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/b08e388b433cb2c9dde74be0cfe836c7.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28f05712a2d3b02c7bd182421d9bf221',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/4dc7e681ff1e62fc0595def7eee826e5.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d95f9d06f3c7a26b8d07d47fc353119',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/cf89d4a7a83357a0b24f6ecb3b477649.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ec4a72e3cfd88876d088bfb87b70dc7',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/f18454da555f27e292ff4f80dde75744.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40d9d3133adf3f136aafd9d9039f558c',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/5aafcd077d7ee47129275a60c7b6f9e0.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44529d166fa6aa392cb1b6eac573c865',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/bc5226d4c7baf4b7466d9189cfc2133b.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa8fc6066a28a3413004d7afc1b0611c',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/1eb2dca0920588e6b905f9798637239a.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a95527c94549540803a22efc5ce3a248',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/b07f4250c808adbc5e240f4c1a18e3be.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '388700e24d5ad5043f2a390c46157b00',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/8c8192c615205ed0ccd04f8589bd293e.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cb4dc04e4643fdfb7b4f90f9218eb83',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/d7c5b8317772d15842a42d5f5f929cdd.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6468a4e4ea649c942cdd8b1c47259da',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/07761e71315d5649c6d81758ded1304c.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21820623692e42e448b4abcdcab5e5f8',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/37cab00fd94d59cf03c3c6cb0c118199.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '718be12890706918555fccd2ee4bf926',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/64566af681e3d2fbcf30ea72d59a4e51.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f97ac9d6b588d51b2a343403c362331',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/b553af6e48eb41c4a1ac50d66f8a08bb.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ca1911de9dbcd3a8bedf84f651f1852',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/eef726f44461fc769fc340f88b1a8b4c.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fadfa5dbea0bf66adf89e824fd1d8fe8',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/3b1c4fe68308c90473e5376afb6948aa.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb5093c307e2a39e3093cc0f8f80e151',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/87b9cf1bb1a7f122093d9b50788978e2.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6fab5062a17a94593e48a7ea427ecab',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/227e28abf051f22008e0980c1fda39a3.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a83ab4a5d3d6d872f40fdc14b42fadf6',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/a75a553882860597ce33f77d7f178c1a.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0919601baff7ac4490a9cde552368982',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/7554d0cc86ededc5f85ade8cb921f15a.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21a2652a85d8c1adb159e323b277bb3f',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/cf462ba802f749ceb936337c0fa08a8a.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4231946b6ef3afc9417267eed1ec8198',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/80b0395aaae5d312e441578242569d12.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '637d5dd4ada5fb5f5811e5e6706a1af9',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/26e8685d168980ffdda2a23474362adf.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b2cadf3e5745fb3a805475aee12de22',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/dbfd0a3a3a171cc207f7609196c73ed3.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d81b61e38f36dc35b2119467b610556',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/15b4a1e1510b0e3ddf911adb689eae28.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffc9106bb1d9966ab01e6d9086a0797b',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/c343bcde7cd431eaa89eb0aaaa369766.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eecdce07cf936d518c1a090228c79c5a',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/9334fe62190a9d5cb1c21c9f258087d7.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47ff8e1f389fe46393933abc0a6df5f3',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/52a99a025f8ea07e7b4a19d420e67812.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36b6c3642336cee3e2c2c36979b197ee',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/ff4438c00dd7ea625e8476161ec15df9.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67488dd6da797c8f93ea5cf460f763f6',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/36353d16ae92dd9758ac55585e42b14b.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c1ba7dedba0a17db02bf1e7d2dc1b00',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/c61c74a99c20d64302790d6460f9801e.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14e5f9e9b53e0784f3a3de96fa1b9b01',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/22b632739337ccbe07937fe634e2897c.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19f9e2055cd0fe84443297726af4dea2',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/34955391c9ef3d479ead4df1e0f6628a.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e2112d6277936aa98d4de47f199a5c8',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/8b7cc7c320604426013b948580b6215c.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96aeebc2da425a426ca5c7ad758d7a79',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/0cf8d96da75f250c0c7c07403e1f1c51.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9be2cbc6796f71231d74fbce5411c32a',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/03df07674300c8d659ea58d2ca768510.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33d366d4d2071563986e8be6cafa162e',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/9006b3783bde1fa837b832bc1141badd.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af41f9cc453f2622c99e8a9791772998',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/ef2ca2b40256b6f08cc53ece5e8705d6.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '600363180cc2138f00cbf8c5f75b531b',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/08d8d670dddeed3dc86145d0d522f18f.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39dc9561ca61e6d9885a11e4afe70f11',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/75034807ffa4a0140aa82766cea35f92.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70fbfbc11dc287c9d193d50eadda3750',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/0acb4132eb792d224cf5c4afd0b0ab90.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4d3cfa8c441c2a6090a50af90fbbee8',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/31e691329dd94af3bf2c48e83a6340fe.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b1781f3a88fab80920e5d7dad340c3f',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/a31a40d7ff0f60ba3635117dd293d5f0.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b64fd6fdf30efaeef7df210c68031c9',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/9a615dd00756e40d1e9b8318ea1b66fa.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e468639386b0314552155a81ab93db8',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/f4f4230ebae03c5245e01c7a6f08c798.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7eef447173d561eeb10970f6dfc732d7',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/b6a1bdbaa8ffb252b767f7415ebead72.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef6e33066947dd7500c91a46dbe22692',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/1b4234fd38f6d016c30db29b19b98b79.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c20ceba710783c6b7e9e9b5b38f77217',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/c866596fc536a28f9ec84e2bbae10004.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '759750834a02d3a202a8e16f4dd793c2',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/77bfd0c44d2038610f8aeb04b3929f5a.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '915fa3c6649a8b1dae51b46876c30612',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/cd99e1eb2be64e3136af73673e9c7c4f.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c05941191180a1de859d5d09af61eef8',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/7e9bcc6b7e93a03cbc3b4e7b3ce9297f.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6d1d9a98d451b8804f57aa72b6e3d0e',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/5ced89f2987cffd460db21392f899745.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5fda8e428864d20984e239214e04240',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/49a00a48ec6dd377ff8afb561fcf07db.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd302f3faa3b9e2cb96d3ba90fac3112b',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/9ce810f603927bbe43542770df30d40a.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf74965329c7c99c85761229c41d89fe',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/8b26c70898d28e066401109954bacfae.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6a3c53dd5f420dd8c7136d0f29f7a40',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/b9d5ff6f53e6678ab367f35135a15017.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c76d97c9fd81dc9a072c4005f314b52b',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/64f0967ae789290152b7bb62c4ea3f68.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abb39047c16264d50b6677ad33cd1322',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/dda4d361b49229742f735cda84fc6a33.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10a7d63b6aab4dc516afe891e726412e',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/66d0805845ac29b74d5a0b7635b8274c.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fc7c165f8b8f7fcba1f429236eed6a1',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/079db3b397da3bb583c74ddd8f85a060.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d108d247ca655797c3fa960dd0fc09e',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/83e008e32c4d663229542b42325c3b35.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23370e22edf249b74bcf14b09136064a',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/b29cce2bfd51068783a47b1aa196a9e4.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '895fce8f807b9c46cac671a3d5246659',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/b80b9795fb86b98135e8361bfc860d90.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eff695ccc9a80de78474271e6a156c01',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/358e935755f1eef8a771dfa965ec0eef.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65bb1b4c4f89a26611e34dadebc47268',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/6c1b0fb8b305ce8bfd25811bbdcd2180.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2585c5be487dc93781a5aeb2b24edc5',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/8fc956fc8e2b088610c8e133f835c3c6.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61b9c297c247a05ad79c53e1f0cd4a1e',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/5a894d1911fc08163669eff31de6c083.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5369483b997481b23babef5e737d127',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/4fc43f830771fc60aee3f5660fb9ae8f.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bd54a7459b60cfee2125fda0427333d',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/0897f05b71307986c653809cc381b593.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '182dfff2e03b09328b59541922ed14b4',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/4a08ef2e10b24e1c5cf8d8df6d78be0a.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19ee1bc3a7a9dc39b92dd1e64f05730c',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/bad7bbf383f2b06111d97c7b4de6f296.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14aab289a398d3130dda7084cae29375',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/968ffaa666ff309da3549a42a933ebb2.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d9c4b487eb41f818942dcbfd2460a12',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/5c63c69429430a91df775e5f3f2e99ae.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8bb0662b63956a5a2323d6f4beaa528',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/c8ba8a1da05808d44f790ca5e24f87ff.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e7acd9ac6c6689491900d80c8c6d901',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/dabcef55e4872695be97a8d7c33b2319.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e28defeab8ed2f0fc17b952bf59446e9',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/60c8509879aab956029e95bd68ba5fb9.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91f1532fe3e47aea8b8a04c6528eb49c',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/90d651dce5fef26d8be5449252995a2f.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3bcb203f559e0ce7b7c8ad52715853aa',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/ea91a9c14f8673f97b0e2b059974ed99.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfa6acc69ee9f97cb3c59a9cf9ab7f05',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/fe95380cb4cf4b72bb45bac0242dfaca.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c19da49a9c4da2b211d665e9141d2507',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/f70d89012655c8f0fa902cc79ad20e5c.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1eebaff1ec6987cf2846f25d7337bbdf',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/7a29d5dfce7a22b86631fc78e8da3ca5.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9eaa85c03d9fd93ae0c5a3ad1aa3166',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/eac23b4610a4db1bc815d388c23dde71.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2929355423baaeb7e28df3a0e99aadd',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/7a395cde8aa7a5aec41ed99109dd4861.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '885d919beffd2dade94e842ba1adfefb',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/72d1f2b109c952d8fa95a966097f2c4e.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b3250114d4df3eac52aee48241ba111',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/8c6b53ca4d21ddff7b30d7b698db2579.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9179fbe98f8c8b02cf41672a405b26c4',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/7f17473777ac8741687b7133235871f9.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73910b5ece8f30123d3c6b6a6a25d917',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/84da23f237f02b2b85ebd2380f856bf0.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fab0cc316827406a81cc4e80c0a05400',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/c0018b1d9978c121a6f62187985ad258.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce282947ec267462268aa89141d9ed8f',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/8cabd84b8d42aa7ba82faf0627c39362.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1e2dfed96637eca4cd6f474568af22d',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/c7b92e3ae1095d7ddd734520a0c49abd.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4279ee3383f6db911536735e4a75124e',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/1c8eb40f5297ab3bacc4c236a4710a63.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8d4061ef2f50442fa8fe7f479b26338',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/a2b67f350b1428e653b5a24e8967ae0c.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1eb93714fa0b9c66a8352d049c9bbaf6',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/263077b8e891bc53f81b4d57d6eb3426.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e676ae384ee34e111a9ed7bdf546c2ea',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/ec4d6c36345efb85dadebd31b15244f4.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfdc9271716050ac9a666bba9f1a042c',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/4dd5af5158484512b52013ce7dec71b3.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44871450c4bd857a7ce09c1da8b0b80d',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/55171890e24798b633b4814d9e6b7861.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02da4da3c252608b347368af53f6a9af',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/170e799ec8ca87cec193c960bd951332.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d375f56fc33ac7d5c9e04d7f7a42656',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/29ddc43873b67787dc9aa1bc730ee9e4.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '553cdf4a7bb25da55a8812ed0a821a1e',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/2642552ad13869930cefdbda7839e8b8.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e3622f3d63bcba5ed9f9ff736919fed',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/61f1c8e3a9c424fb6c5a0f3597510f73.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f97c2cb570a1e3aad4eb6712d30e977',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/50354a0ce8f7098cd36da6844ee6b576.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff388257c2c154b59accac37bb686b22',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/bd6d9e30bd092679df19ac1f4280e3cd.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91900ee17422f9b3b40dd3a0afcf6db1',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/866fc5a83b4dd2d7ac1947a5c6aae39b.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5377b13253a3f54320403c6cb01ba3ca',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/4f08e26a2e479934b41e16a5bf426bc0.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8377678491591a37d0afe9f24460540',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/9ba10c8653741631d3f4da26f9f7411a.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f63a4bfd5a51275d527084c5394943b2',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/3c07089f647ff85f11aba2d95ff720fd.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb7c50d16a13e4f61fcf490313742bae',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/36db0bdacfbb7973a36fbd336c996f31.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b9c6e2c7950d3d5525f097d7a9243c0',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/c52bf6ac85e79be50acaebf6fb2fab24.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c5b85ee5da93b2aca95a355ed9e32ce',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/54f4e35ce0c63e0e346c46ed0419d1ae.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d1822ad9e6a28ef9ea1cefccfa8bafa',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/2d3f6e1b43f79c15d623318aaafce51c.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cc3c1dc37889d76fae99baca35de486',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/73f441ddfd5f1d10674384453fe40c85.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c393ca7a2b4dbfb4b436b46a828a613',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/1e1949d20cfd049f2400692169aa074b.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b4e4cc0d7cdf9182bf75b852afc48be',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/8c27782f07eed2294befd70335a5231a.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd82f6490d61715c72f7856eee9f6c04e',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/a60222856ed58f98a0281078bfa3a192.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '986e2f647db23670e58caddfdf4074bc',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/78ce9654b0c2f9970abffe9ee9ce8624.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdde5ce131c8eeeb9d8e60560a637943',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/e501aa53934606ba6d0dd24f3eeb8986.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69b3ea073d4a7604543cbab1b73e96a3',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/7c5b44dc553445bb8cd09474a300d029.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29388e7be14cc40ebccb5cfd199a7f19',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/3e24a6416bfd6fd6333004884e85b89a.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03a800d613773774af906bbbb6e9277b',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/95e3b76cdf75980f791ef5e4cd6ce147.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2daf00338ce1300eab45970799e0a3ce',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/db612511d2622f954ef8954f2f744be4.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56ae6c7be0ea235138c36d443d074812',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/92d4095556c64130a270d488137328d1.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97562929bb68b365a983316c4c128e5e',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/86acc067fcc6ab48b7350887b30c1c32.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1ef2e8f20f78c3fc71f455f4067c833',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/a3c8411a8e60619de126b6e2b0900e14.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad615ef66892cbf05493a2ed907bd7b6',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/340551579e4e32102aa25295b0686e62.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16db61c0ed371ce51cde14a713769472',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/3503dbd75b6628a8e583e48b43c81fcc.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '245a61c084c12c660bcda0b2b0d04b75',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/aad80854170242e22d6ba203c3529e6b.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c97d9de3dd2e9ee259372e60530e83b',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/bd0f7796b51e5a87ca6bbbf9e29be8fb.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '847f9aa182860d96b81c312b73847f16',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/0cd1643fe853d4fd385eef010e467475.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '829d205977048f5c860352b0a127aecb',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/edb3f17d045b8df95773850aaa8838b0.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '420ebe7068850f4074ff802f9d40bc13',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/81f18550c775a511e300141c68cf7ee0.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5720b6c461914fe3abc59f2ce7b79ab1',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/98e89588724138ded2719aaaaea2e2b8.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95bba0c3f01485b58238a399b9e33963',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/817aa2f690a87efbd0752ae9b1076f43.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62eb2db199f1036a4abbb2edfdc75c37',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/2b464579722c27fd55e74f4a887d079b.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c19f151b2d3d36f50715e0d9fd04bd28',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/eea6eb6680f052821539594140d66b6e.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42ad23ee32a42bb93f9fc2358be9c925',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/4c0a129de516a298c70b7cab1c876e28.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '220756df43781f1326daf1397ca4b88a',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/994d1dc7da94b51e918464b7e9ed7574.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '168450382710c12caba4b41aa30f1020',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/a84c76eb5c1f5c4615502fdfb0bfc120.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d06ab9a07c97748fbe9648909ae7511',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/01fa341a35d5c44e22bd7f490cf8e4b7.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b53fa68fc4927f1fae73eaef2e7fad84',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/4ea629d5a6f97f7855905cbe8eda5b9b.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9175337e32341edaebfd6f2ffd42b8c',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/bdfddf5ef1051d934973b447b517fcc4.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2a93061f129d4a6f92dd603d1b25fb4',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/46bf601752784082c080fb3cc741000f.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a00461f223b8f32100fa722ee962bb89',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/f7e477d4aa0d8a55daa56d2fec507b07.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c66fb185a4c3f5dd98041418405655ee',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/7c9dcf0c9256b646f2d81cb9e65113e0.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88b89972f7b9790bfb11a2a75eb1459c',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/cfce5616626bbd77133d976fd0bcc54d.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7410256c1e72e5798de6ddede5833f8a',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/4af3b42f95d2b527a28f49af5c6c98bc.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc3474c477920b445f0498284b7fd563',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/972ef409994711c937b3fa203def0665.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a28132d1adb6279cc1d9428ed02382f',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/eb8b8cb8329549b1ec41849f132753db.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c99046b17457d6a486240830d31e2f5',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/93b67945abc5c6202ecc0305431318f5.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '136b6eb4e42158c5385cee7b84d7c7f8',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/409578d14bc3ccc1b501b2b83f46ce49.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '722d2e416df3742b4afc5b3a32f3a353',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/352add5052ec35066528bbca417e5623.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a0d6e85d066bb55eae16797e1e69bbc',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/f3afae5afeb067c408708ad319845dd7.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e3cc6861fdc0b695751c8599a929192',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/50eb10e8f2f5d972c730d9c1eadd6895.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79819b7a7a16f0ff656f1d82c872a412',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/ced67f4de42876040ff557ae250fa323.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e9af3df6e09e8a0bee8e2d0c5a95169',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/6e5e30f4f3f8396ec6f923e42919c5c9.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5eab6de420cf1ebe635761b99e302107',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/727b70a8f4f54117ed28cf9be4bc7796.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61823098d8b2f4237f00961a849fe2d7',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/b43d38b8a720528d248f08c143526e92.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '436bd6f368820012666964ed3fd69e6f',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/0a744f8744e23a99b5e89607dfb9f567.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25a8934fa0407eb8bdeb867644b683d3',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/0db60c6d169cad63fff4d7ee11371766.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5154914aa03577f4b3fb7a1b3e0f8cab',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/80a76ed8af0341eeb9d41e2733c3a6d0.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c6daa6097542fa441389635c569328a',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/c6256bbc6811182b11470c8538aa7608.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56d3437f14d9a038e3481cde7caf365e',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/8fe9c4697ecb6bb94f368a3947387d96.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b00389dc380a4da56025cfec925d5d54',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/a6ee70feae32ab3184e2f286f6188633.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53acd8ab4d64207d8593e89ffe8ac3da',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/130b0c35426a57a12e992dd7abd3c6ab.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2269831a4f5a3cab25784ea34689b08',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/936a00d66a50eb9f62c8cadfc1a71dc3.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b514536b98a1688c81c856f978b9047',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/9384a74abc66abd0c1333de20a08bf1b.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6746e6ad5f09e25e3360cd217529bd1',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/ac665688fe3007a7d7632fbcc295fed6.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7417c593e6fc5ec149433dcd7ad58820',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/0d8aea618a54fae94c4dab7b00649ab0.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '311581e3fd67a5adcd7b9cd973afc436',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/b85e0146053dd99adc185d6c7173d28f.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a6115e931f89267fdb073503a244137',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/f23d82194c34dc698f4772ab5b3f6093.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd093dc67d7f4de17c182f69c928cf82d',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/e390018f3e2ced4d6c36d894a826b285.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14dbde72b7692141fc63c6f70588d2b7',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/c8c5417106430b98c3a3b92a9335d575.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b399a88553052b04e1cad451b685f8f5',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/9406607fbaa81784ea92215ccd003204.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20f15f82387e9869457978b86d68bef5',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/c3b377ba63edb7200dca0ecafa7b224e.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ea32a41154d994396f311711b150df7',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/b9ff914fb22d7e122213310a588a9e42.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff37c164b14be8c1e09a3d79b81209cb',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/732eeae28de08cfa4176721c70b0c970.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12fbf0c4e3a67a1bc80cc542d5bc03ff',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/a503bd4226d9ec7daeab37900d283854.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e68bd4a190e3d755c87a7c5a84e4055',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/14930ce3b988154ebf57cf4210ae55b4.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cfdd9c0b6c61890b9f91c0624073829',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/1b64ac7ddd19c4a09d41d1705188dcd0.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ea26f91a0bda80c2225ff8d621b57d3',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/7f3f3e2d0d95d1910f4b620d414656f0.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e7983fccd0576259a91d30e7432ddf3',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/7890f01f647712dd157f5513ac3642e4.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f76544953836b174256e7608df25ab73',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/bfecfb8788563d79a58ca88bb355538c.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b918503a996c8d0ffdcd591cc2c5833f',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/a0905e5bf3e0e3599bf7417b4d77af3d.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73fb45b9270940fd6bb02a72c9cac3e9',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/9304c03d2841b57471c7a587337b0fc5.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a74d7366c56430fde0292d4d10477c14',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/9ee5a0ff8cac053627c1561e54561306.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e8c3ac2ea24aaa7be8d0ceecb24dc04',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/8a6a753f224775ffc24a717b56c07df1.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '338f2800ed4edeb0008590f83633a412',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/a86ee2d1580dd2959958b7c91cd31e63.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbd6be31ed21e55c0d70a94c9b61687c',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/4cf918ee479b3f2b9bbdb3dd83730b96.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8ec375998e324471decc705de7bcd9f',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/f495fa4c5027291c6a559090c2bb2d4f.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89be473ede48e377f21fbde31a231413',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/0d71be2f7fdbec350d7aded013762bca.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1aa77c192c0ed6b23e5448f828e7ec0',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/ae10fa72e0a3e6a5bc77715cba6a7db9.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '079db0b520fc0bf9a40ca530cdaf1adf',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/574f7355141dc0b17c71f8f555f604e5.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfe19609a0f8b5897cf243c3d1b0c25c',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/494bc2a354788af7cb368aea8b5b42eb.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3205e662f59b3b3ea065cda8031aebe',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/06ed21b240d8596b7cd8adea3238d35e.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1c6858f442c63a6f68d78f55d0bc4b3',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/0110fb9d1073940cc75b6161e2627c7c.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60e9c708c0813e8afe048cbb895fbaba',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/49fe4522b98c143389d592eb4d55c14a.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d19b94a4b26e5d841add00ed8ac0918',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/1f6afda286b40827995760b5fedfa9d9.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce97b7a4d620f3f617b35b486ace84ec',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/d915ed8052af97cad3d891b6e97fcc19.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0e79755611ecac8b5ac2723dd7061f4',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/4900f8ca7fe944cb9b8c3661ff933d31.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '718d1c50fce1cf2e3d9bf429d0a6f2e5',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/f1253948e80d6bcb974e24f7a1e18deb.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f41027208d4623a44500835b5c0d785',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/9fc59ea1e8bd603f7ee298d79dfcc833.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0503a87e2bf38163d0798c538948f025',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/885ba71f2bc39ed286278685501afdb5.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71a8733f0e565d1701ac56af8a36ee72',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/be81ef7ffe8732d4e440d3bfda1ee4dc.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cb0a1c26a0960b708cd039f472012b1',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/fc096e2b1780382272efec75f39c2518.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33cec1c528e8b860ea813f168f224e13',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/16611f3ec20b56eca829ecd47477919f.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd29742f415a5b3f08fe57f84e6c8d794',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/dc57bce4facb0f9d2923de637c8f4849.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efcd187198a436151e6440171ff4383e',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/ae1f0ff0bb3c9e4368f873f82eb6533d.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '101f772c996a4132e4c12b9efff737b1',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/16e7feba389931d068cd8cfc58b0daf6.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '9039a27473b8dc6ebe55f72dbc9ee81a',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/1d67e9496de372a6dcfc90d3f0eccd5b.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'ba4958ed90ed4a4a26b4a8c10d96c897',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/ab6b2057b473ec2987570317a8249a7a.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '3827741d383b8a831c7fa877184bb899',
      'native_key' => 1,
      'filename' => 'modUserGroup/c403e2979959bbfd460dc85da3375786.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '1d833b6805ecb83a5921f389853d9837',
      'native_key' => 1,
      'filename' => 'modDashboard/864b96cd04cab79f84df5c1ed7000bb7.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '071075ce23e84598043360c4fb8c0eb4',
      'native_key' => 1,
      'filename' => 'modMediaSource/12ba052e3736fa1d05b67db5addd1765.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '98be50226a6b2ba2f6959d43f5893edd',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/184cb488300e223e54cd828508ddcc2d.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'bb11817110fc298a7fd312d7c1f49fe0',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/8a8eef3b820360cf28ca3ace92978798.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '36073a9b9aa8c1a78c23dc284480e252',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/c87849441f6b0614158c9aaa2a81897f.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '3142cb5065c1d7f30b76ef0605b725ee',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/e3da58704ff4f7d9ac77917cf764ab90.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '70fc997586ebbb758bde6ebfbef0deb3',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/aac4c8a2e4ebbf6a76bd70c3d99ecba9.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'e02125541b81046c3416f381ddf5954a',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/dffbacea3f58c5d6b9d1a668401d2c8c.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '1ec131cf3b602fca30594f21347c2e8e',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/42bfe78c271aa31e126bc51881d7690b.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'a9fd21dbc7e7389bbb2b5901d6a17e18',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/4ca943d511791af668ed52abb45e8952.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '9c3cc311196f271eff180840be4784d0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/a6bcf247c6df72fcdedcae26dd3e2b72.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '201a2937f16d2b6117abd18477e84e0d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/fd92ce530b1e94ccf11f0935ac9d6463.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'f4796f664b5e4f80f59c59c8a3ec4f33',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/702941787282bbfbdfa360273f641968.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ed254488f1362ed79aef967767f8e5e8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/502a98248f62188470d28a74e74add61.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '0dc556468bd161d8e98141cb3ffaa569',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/eab83c726c4d5ae3f19c751aa28e9db6.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '73b3c7b2ea575a283b143dbd91cc238e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/17c9f2f3e9dc0a44791adcb6ae052d69.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6bf9a09a63e15fbe744e5c82c40419a0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/28515fc65399569d64cd07170e8e890f.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6fdc4e2a5be9a49dfa42f3671bc506ea',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/455aacf8f8a5a572712fafdbd95fca11.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '847af714b93f8a801d324e26724cdc35',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1f9138f3dd2505b070f5548586f72985.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a0fcfecdbbe1744284ac7abaa9c30450',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/a9262c3ff889b8f44a0485230992df88.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b8361fe7b80a2718f0a6a8ecd8057809',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e0a2719e1d36132a1409cefe2a11a7d1.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5693d7d83ef5599a485a7fdff4b9f056',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/96757349edf0eea69a11d50e3225dd75.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e5b67e7ce498a70db0a77a3375ea6f7a',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/d17633359f04d7a3537c9459cb320d43.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c7c8f4efb0a7f1c80f2e4083829b4e1d',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/7075b1d3dab9c1664404c6160541d258.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7a17d4abfa7d671c2561023a8fee08fb',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/c9e0938c25a7bf44077e7e04c3372e3c.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'fb7ea066b1a64f3d8077f64202a4eeb9',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/7ebfb8f49c74e436ff16179a74248ead.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ee76d4ba59d4fd07a39047604d793154',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/4e24ab680b343f60b80f436586a81963.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7650e6adc9c581ae224f3623a0a4f05c',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/6e46e3e19e972d0d0899c74d1be0719b.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f219e268c1857bea38fc7d6c22547aec',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/7d434e5e8f75b95a7444b570d3d48356.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7369d67183ae6298ad74eea296516d17',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/7a5cd5d0dbd497e5411593688e70db44.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a929959ae99d7e76d87eab5f954de673',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/3ac05363bae3371a065f5a4dfa3927a1.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8e5e63fbc6cf99f3e063dac2aa2417b1',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/0d334d22b1d35dab9e5c88417bf0bd15.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4448213592d3cc9557011c2c76e4863f',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/375db5c67013bdf3e441099f17f05663.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4fd7217824ece745e5c6cdaa27831bff',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/f17115fc31bff8167f9eecbad77cf4fa.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'bce342fc9eee862164d4d6089c319acf',
      'native_key' => 'web',
      'filename' => 'modContext/8a3bf4e891108c1354198d755ca758b3.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '9999fdba87647ffab8269e0b7d1271f2',
      'native_key' => 'mgr',
      'filename' => 'modContext/90355abecf61e2377edb190691e864a7.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a92a3ebe3bc7c0d1ecddad1bad74e07b',
      'native_key' => 'a92a3ebe3bc7c0d1ecddad1bad74e07b',
      'filename' => 'xPDOFileVehicle/0fc02ff77ca9d46760bbcb8bbf9ce50d.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1b288f1099f089f840a00c96b02e64bf',
      'native_key' => '1b288f1099f089f840a00c96b02e64bf',
      'filename' => 'xPDOFileVehicle/f6c1c279d233846356a78a69070387d8.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '966ebedcbbb5f4bb10fc9dd07537f6bf',
      'native_key' => '966ebedcbbb5f4bb10fc9dd07537f6bf',
      'filename' => 'xPDOFileVehicle/69419daacde629742cfb354943ddf17f.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '3e44f964b28a3ca38657081d2681da43',
      'native_key' => '3e44f964b28a3ca38657081d2681da43',
      'filename' => 'xPDOFileVehicle/a9d822b449eed5d6135fad10c73f0cc3.vehicle',
    ),
  ),
);